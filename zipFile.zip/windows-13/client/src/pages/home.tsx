import { Desktop } from "@/components/os/Desktop";

export default function Home() {
  return <Desktop />;
}
